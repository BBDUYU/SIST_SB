package org.doit.ik.board;

public class BoardDTO {

}
