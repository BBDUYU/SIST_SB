package org.doit.ik.board;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BoardRepository extends JpaRepository<Board, Long>{
	
	// 목록 조회
	Page<Board> findByStatusOrderByCreatedAtDesc(BoardStatus status, Pageable pageable);

	// 카테고리별 조회
	Page<Board> findBySubCategoryAndStatusOrderByCreatedAtDesc(
		    SubCategory subCategory,
		    BoardStatus status,
		    Pageable pageable
		);
}
