package org.doit.ik.board;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BoardService {
	
	@Autowired
	private BoardRepository boardRepository;
	
	// 1. 게시물 등록
	public void create() {
		Board board = new Board();
		board.getTitle();
		
	}

}
